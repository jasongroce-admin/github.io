param([int]$Port = 8787, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
if ($Port -lt 1024 -or $Port -gt 65535) { throw 'Invalid local port.' }
Add-Type -AssemblyName System.Net.Http
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'site'))
$rootPrefix = $root.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$handler = New-Object System.Net.Http.HttpClientHandler
$handler.AllowAutoRedirect = $false
$handler.AutomaticDecompression = [Net.DecompressionMethods]::GZip -bor [Net.DecompressionMethods]::Deflate
$http = New-Object System.Net.Http.HttpClient($handler)
$http.Timeout = [TimeSpan]::FromSeconds(18)
$http.DefaultRequestHeaders.UserAgent.ParseAdd('groce-eye-local/1.0 (free public feed viewer)')
$http.DefaultRequestHeaders.Accept.ParseAdd('application/json')
$cache = @{}
$mime = @{'.html'='text/html; charset=utf-8'; '.js'='application/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8'; '.json'='application/json; charset=utf-8'; '.png'='image/png'; '.jpg'='image/jpeg'; '.webp'='image/webp'; '.svg'='image/svg+xml'; '.woff2'='font/woff2'; '.txt'='text/plain; charset=utf-8'}
$mime['.wasm']='application/wasm'; $mime['.gif']='image/gif'; $mime['.xml']='application/xml'; $mime['.md']='text/plain; charset=utf-8'
function Send-Response($stream, [int]$status, [string]$type, [byte[]]$bytes) {
    $reason = @{200='OK';400='Bad Request';403='Forbidden';404='Not Found';405='Method Not Allowed';413='Payload Too Large';502='Bad Gateway'}[$status]
    $head = "HTTP/1.1 $status $reason`r`nContent-Type: $type`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nReferrer-Policy: no-referrer`r`n`r`n"
    $headerBytes = [Text.Encoding]::ASCII.GetBytes($head)
    $stream.Write($headerBytes, 0, $headerBytes.Length)
    $stream.Write($bytes, 0, $bytes.Length)
}
function Json-Bytes($value) { return ,([Text.Encoding]::UTF8.GetBytes(($value | ConvertTo-Json -Compress -Depth 8))) }
function Read-Query([string]$query) {
    $result = @{}
    foreach ($part in $query.TrimStart('?').Split('&')) {
        if (!$part) { continue }
        $kv = $part -split '=', 2
        $key = [Uri]::UnescapeDataString($kv[0])
        if ($result.ContainsKey($key)) { throw 'Duplicate parameter.' }
        $result[$key] = if ($kv.Length -eq 2) { [Uri]::UnescapeDataString($kv[1]) } else { '' }
    }
    return $result
}
function Get-Feed($query) {
    $source = $query['source']
    $ttl = 120
    switch ($source) {
        'satellites' { $url='https://celestrak.org/NORAD/elements/gp.php?GROUP=stations&FORMAT=json'; $ttl=7200 }
        'satelliteCatalog' { $url='https://celestrak.org/NORAD/elements/gp.php?GROUP=active&FORMAT=json'; $ttl=7200 }
        'cameras' { $url='https://tie.digitraffic.fi/api/weathercam/v1/stations'; $ttl=3600 }
        'aircraftGlobal' { $url='https://opensky-network.org/api/states/all'; $ttl=120 }
        'aircraft' {
            foreach ($key in @('lat','lon','r')) {
                if (!$query.ContainsKey($key) -or $query[$key] -notmatch '^-?\d{1,3}(\.\d{1,6})?$') { throw 'Aircraft requires numeric lat, lon, and r.' }
            }
            $lat=[double]::Parse($query['lat'],[Globalization.CultureInfo]::InvariantCulture)
            $lon=[double]::Parse($query['lon'],[Globalization.CultureInfo]::InvariantCulture)
            $r=[double]::Parse($query['r'],[Globalization.CultureInfo]::InvariantCulture)
            if ($lat -lt -90 -or $lat -gt 90 -or $lon -lt -180 -or $lon -gt 180 -or $r -lt 1 -or $r -gt 250) { throw 'Aircraft coordinates or radius out of range.' }
            $url="https://api.adsb.lol/v2/lat/$($query['lat'])/lon/$($query['lon'])/dist/$($query['r'])"; $ttl=30
        }
        default { throw 'Unknown source. Available: satellites, satelliteCatalog, aircraft, aircraftGlobal, cameras.' }
    }
    $allowed = if ($source -eq 'aircraft') { @('source','lat','lon','r') } else { @('source') }
    foreach ($key in $query.Keys) { if ($allowed -notcontains $key) { throw 'Unsupported parameter.' } }
    if ($cache.ContainsKey($url) -and $cache[$url].until -gt [DateTime]::UtcNow) { return $cache[$url] }
    try {
        $response = $http.GetAsync($url, [Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        try {
            if (!$response.IsSuccessStatusCode) { throw "Provider returned HTTP $([int]$response.StatusCode)." }
            if ($response.Content.Headers.ContentLength -gt 12582912) { throw 'Provider response is too large.' }
            $input = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
            $output = New-Object IO.MemoryStream
            try {
                $buffer = New-Object byte[] 65536
                $deadline = [DateTime]::UtcNow.AddSeconds(18)
                while ($true) {
                    $pending = $input.ReadAsync($buffer,0,$buffer.Length)
                    if (!$pending.Wait(18000)) { throw 'Provider read timed out.' }
                    $read = $pending.GetAwaiter().GetResult()
                    if ($read -eq 0) { break }
                    if ($output.Length + $read -gt 12582912 -or [DateTime]::UtcNow -gt $deadline) { throw 'Provider response exceeded its size or time limit.' }
                    $output.Write($buffer,0,$read)
                }
                $bytes = $output.ToArray()
                $null = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
            } finally { $input.Dispose(); $output.Dispose() }
            $entry = @{status=200; bytes=$bytes; until=[DateTime]::UtcNow.AddSeconds($ttl)}
        } finally { $response.Dispose() }
    } catch {
        $entry = @{status=502; bytes=(Json-Bytes @{error='Free provider unavailable or rate limited. Try again later.'; source=$source}); until=[DateTime]::UtcNow.AddSeconds(30)}
        Write-Host "[$source] $($_.Exception.Message)"
    }
    if ($cache.Count -ge 64) { $cache.Clear() }
    $cache[$url]=$entry
    return $entry
}
$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback,$Port)
try {
    $listener.Start()
    Write-Host "groce-eye is open at http://127.0.0.1:$Port/groce-eye/explore/?local=1"
    Write-Host 'Free public feeds only. No keys, accounts, subscriptions, or billing.'
    Write-Host 'Keep this window open. Close it or press Ctrl+C to stop.'
    if (!$NoBrowser) { Start-Process "http://127.0.0.1:$Port/groce-eye/explore/?local=1" }
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $stream = $null
        try {
            $stream=$client.GetStream(); $stream.ReadTimeout=5000; $stream.WriteTimeout=5000
            $header=New-Object Collections.Generic.List[byte]
            while ($header.Count -lt 16384) {
                $next=$stream.ReadByte()
                if ($next -lt 0) { throw 'Incomplete request.' }
                $header.Add([byte]$next)
                $n=$header.Count
                if ($n -ge 4 -and $header[$n-4] -eq 13 -and $header[$n-3] -eq 10 -and $header[$n-2] -eq 13 -and $header[$n-1] -eq 10) { break }
            }
            if ($header.Count -ge 16384) { throw 'Request headers too large.' }
            $lines=[Text.Encoding]::ASCII.GetString($header.ToArray()).Split(@("`r`n"),[StringSplitOptions]::None)
            $request=$lines[0].Split(' ')
            if ($request.Length -ne 3 -or $request[1] -notmatch '^/[^\s]*$') { throw 'Invalid request.' }
            if ($request[0] -ne 'GET') { Send-Response $stream 405 'application/json' (Json-Bytes @{error='GET only'}); continue }
            $headers=@{}
            foreach($line in $lines | Select-Object -Skip 1) {
                if (!$line) { continue }
                $pair=$line -split ':',2
                if ($pair.Length -ne 2 -or $headers.ContainsKey($pair[0].ToLowerInvariant())) { throw 'Invalid or duplicate header.' }
                $headers[$pair[0].ToLowerInvariant()]=$pair[1].Trim()
            }
            if (@("127.0.0.1:$Port","localhost:$Port") -notcontains $headers['host']) { Send-Response $stream 403 'application/json' (Json-Bytes @{error='Local host required'}); continue }
            if ($headers.ContainsKey('origin') -and @("http://127.0.0.1:$Port","http://localhost:$Port") -notcontains $headers['origin']) { Send-Response $stream 403 'application/json' (Json-Bytes @{error='Local origin required'}); continue }
            if ($request[1].StartsWith('/api/') -and $headers.ContainsKey('sec-fetch-site') -and $headers['sec-fetch-site'] -eq 'cross-site') { Send-Response $stream 403 'application/json' (Json-Bytes @{error='Cross-site request blocked'}); continue }
            $uri=New-Object Uri("http://127.0.0.1:$Port"+$request[1])
            if ($uri.AbsolutePath -eq '/api/status') { Send-Response $stream 200 'application/json' (Json-Bytes @{local=$true; freeOnly=$true; sources=@('satellites','satelliteCatalog','aircraft','aircraftGlobal','cameras')}); continue }
            if ($uri.AbsolutePath -eq '/api/proxy') {
                $feed=Get-Feed (Read-Query $uri.Query)
                Send-Response $stream $feed.status 'application/json; charset=utf-8' $feed.bytes
                continue
            }
            $path=[Uri]::UnescapeDataString($uri.AbsolutePath)
            if ($path -eq '/') { $path='/groce-eye/explore/' }
            if ($path.EndsWith('/')) { $path+='index.html' }
            $file=[IO.Path]::GetFullPath((Join-Path $root ($path.TrimStart('/').Replace('/',[IO.Path]::DirectorySeparatorChar))))
            $ext=[IO.Path]::GetExtension($file).ToLowerInvariant()
            if (!$file.StartsWith($rootPrefix,[StringComparison]::OrdinalIgnoreCase) -or !$mime.ContainsKey($ext) -or !(Test-Path -LiteralPath $file -PathType Leaf)) { Send-Response $stream 404 'application/json' (Json-Bytes @{error='File not found'}); continue }
            Send-Response $stream 200 $mime[$ext] ([IO.File]::ReadAllBytes($file))
        } catch {
            Write-Host "Request rejected: $($_.Exception.Message)"
            if ($stream) { try { Send-Response $stream 400 'application/json' (Json-Bytes @{error='Invalid request or source parameters.'}) } catch {} }
        } finally { if ($stream) { $stream.Dispose() }; $client.Close() }
    }
} finally { $listener.Stop(); $http.Dispose(); $handler.Dispose() }
