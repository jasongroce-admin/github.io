@echo off
setlocal
cd /d "%~dp0"
title groce-eye free local connections
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
echo.
echo groce-eye has stopped. You can close this window.
pause
